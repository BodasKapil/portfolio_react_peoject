ts[0].time_slot="S1";
 ts[0].day[0]= "monday";ts[0].time[0]="8:30-9:25";
 ts[0].day[1]="tuesday";ts[0].time[1]="9:30-10:25";
 ts[0].day[2]="thursday";ts[0].time[2]="11:00-11:55";
 
 ts[1].time_slot="S2";
 ts[1].day[0]="monday";ts[1].time[0]="9:30-10:25";
 ts[1].day[1]="tuesday";ts[1].time[1]="11:00-11:55";
 ts[1].day[2]="thursday";ts[1].time[2]="12:00-12:55";
 
 ts[2].time_slot="S3";
 ts[2].day[0]="monday";ts[2].time[0]="11:00-11:55";
 ts[2].day[1]="tuesday";ts[2].time[1]="12:00-12:55";
 ts[2].day[2]="thursday";ts[2].time[2]="8:30-9:25"; 
 
 ts[3].time_slot="S4";
 ts[3].day[0]="monday";ts[3].time[0]="12:00-12:55";
 ts[3].day[1]="tuesday";ts[3].time[1]="8:30-9:25";
 ts[3].day[2]="thursday";ts[3].time[2]="9:30-10:25"; 
 
 ts[4].time_slot="S5";
 ts[4].day[0]="wednesday";ts[4].time[0]="9:30-10:55";
 ts[4].day[1]="friday";ts[4].time[1]="11:05-12:30";
 
 ts[5].time_slot="S6";
 ts[5].day[0]="wednesday";ts[5].time[0]="11:05-12:30";
 ts[5].day[1]="friday";ts[5].time[1]="9:30-10:55";
 
 ts[6].time_slot="S7";
 ts[6].day[0]="wednesday";ts[6].time[0]="8:30-9:25";
 ts[6].day[1]="friday";ts[6].time[1]="8:30-9:25";
 
 ts[7].time_slot="S8";
 ts[7].day[0]="monday";ts[7].time[0]="2:30-3:55";
 ts[7].day[1]="thursday";ts[7].time[1]="2:30-3:55";
 
 ts[8].time_slot="S9";
 ts[8].day[0]="monday";ts[8].time[0]="4:00-5:25";
 ts[8].day[1]="thursday";ts[8].time[1]="4:00-5:25";
 
 ts[9].time_slot="S10";
 ts[9].day[0]="tuesday";ts[9].time[0]="2:30-3:55";
 ts[9].day[1]="friday";ts[9].time[1]="2:30-3:55";
 
 ts[10].time_slot="S11";
 ts[10].day[0]="tuesday";ts[10].time[0]="4:00-5:25";
 ts[10].day[1]="friday";ts[10].time[1]="4:00-5:25";
 
 ts[11].time_slot="S12";
 ts[11].day[0]="monday";ts[11].time[0]="5:30-6:55";
 ts[11].day[1]="thursday";ts[11].time[1]="5:30-6:55";
 
 ts[12].time_slot="S13";
 ts[12].day[0]="monday";ts[12].time[0]="7:00-8:25";
 ts[12].day[1]="thursday";ts[12].time[1]="7:00-8:25";
 
 ts[13].time_slot="S14";
 ts[13].day[0]="tuesday";ts[13].time[0]="5:30-6:55";
 ts[13].day[1]="friday";ts[13].time[1]="5:30-6:55";
 
 ts[14].time_slot="S15";
 ts[14].day[0]="tuesday";ts[14].time[0]="7:00-8:25";
 ts[14].day[1]="friday";ts[14].time[1]="7:00-8:25";
